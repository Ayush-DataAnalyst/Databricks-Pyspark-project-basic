# Databricks notebook source
data = [(1,'Manish','india',10000),(2,'Rani','india',50000),(3,'Sunny','UK',5000),(4,'Soham','UK',25000),(3,'Mona','india',10000)]
columns = ['id','name','country','salary']

df = spark.createDataFrame(data,columns)
df.show()

# COMMAND ----------

from pyspark.sql.functions import row_number
from pyspark.sql.window import Window

window = Window.partitionBy("country").orderBy("salary")
df.withColumn("rn", row_number().over(window)).show()

# COMMAND ----------

from pyspark.sql.functions import row_number
from pyspark.sql.window import Window

window = Window.partitionBy("country").orderBy("salary")
df.withColumn("rn", row_number().over(window)).show()

# COMMAND ----------

from pyspark.sql.functions import rank
from pyspark.sql.window import Window
from pyspark.sql.functions import col

window = Window.partitionBy("country").orderBy(col("salary").desc())
df.withColumn("rn", rank().over(window)).show()

# COMMAND ----------

from pyspark.sql.functions import dense_rank
from pyspark.sql.window import Window

window = Window.partitionBy("country").orderBy("salary")
df.withColumn("rn", dense_rank().over(window)).show()

# COMMAND ----------

