# Databricks notebook source
# MAGIC %md
# MAGIC /FileStore/tables/emp_1-4.csv
# MAGIC

# COMMAND ----------

df=spark.read.csv("/FileStore/tables/emp_1-4.csv",header=True,inferSchema=True)

# COMMAND ----------

df.show()

# COMMAND ----------

df.groupBy("address").sum("salary").show()

# COMMAND ----------

df.groupBy("address").count().show()

# COMMAND ----------

df.groupBy("address","emp_id").sum("salary").show()

# COMMAND ----------

df.groupBy("address").max("salary").show()

# COMMAND ----------

df.groupBy("address").min("salary").show()

# COMMAND ----------

df.groupBy("address").avg("salary").show()

# COMMAND ----------

