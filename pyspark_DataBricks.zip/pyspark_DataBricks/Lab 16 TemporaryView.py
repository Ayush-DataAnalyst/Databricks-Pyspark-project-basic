# Databricks notebook source
data = [(1,'manish',10000),(2,'Rani',50000),(3,'Sunny',5000)]
columns = ['id','name','salary']

df = spark.createDataFrame(data,columns)
df.show()

# COMMAND ----------

df.createOrReplaceTempView("employee")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from employee

# COMMAND ----------

# MAGIC %sql
# MAGIC select max(salary) from employee

# COMMAND ----------

# MAGIC %sql
# MAGIC select upper(name), salary from employee

# COMMAND ----------

df = spark.read.csv("location",header=True,inferSchema=True)
df.createOrRepalceTempView()