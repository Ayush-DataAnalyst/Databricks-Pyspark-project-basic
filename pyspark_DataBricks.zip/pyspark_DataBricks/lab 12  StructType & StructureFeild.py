# Databricks notebook source
from pyspark.sql.types import StructField, StructType, IntegerType, StringType
data = [(1,'Ayush','india'),(2,'Ay','india'),(1,'ush','india')]

schema = StructType([StructField(name= 'Id', dataType= IntegerType()),
                    StructField(name= 'Name', dataType= StringType()),
                    StructField(name= 'Loacation', dataType= StringType())]
                    )

# columns = ['Id','Name','Location']
df = spark.createDataFrame(data,schema)
df.show()
df.printSchema()

# COMMAND ----------

