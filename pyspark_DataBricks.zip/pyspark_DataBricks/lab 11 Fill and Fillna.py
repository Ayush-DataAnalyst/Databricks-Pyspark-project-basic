# Databricks notebook source
# MAGIC %md
# MAGIC  /FileStore/tables/sample.csv
# MAGIC  

# COMMAND ----------

df=spark.read.csv("/FileStore/tables/sample.csv",header=True)
df.show()

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.na.fill("unknown").show()

# COMMAND ----------

df.fillna("").show()

# COMMAND ----------

df.fillna("",["city"]).show()

# COMMAND ----------

df.fillna("",["city"]).fillna("Other",['population']).show()

# COMMAND ----------

