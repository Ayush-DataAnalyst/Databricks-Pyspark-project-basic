# Databricks notebook source
data = [("Banana",1000,"USA"),("Carrots",1500,"USA"),("Beans",1600,"USA"),("Orange",2000,"USA"), \
        ("Orange",2000,"USA"),("Banana",400,"Germany"),("Carrots",1500,"Germany"),("Beans",4000,"Germany"), \
        ("Orange",1200,"Germany"),("Banana",2000,"Russia"),("Carrots",2000,"Russia"),("Beans",2000,"Mexico") ]


columns = ["Product","Amount","Country"]

df = spark.createDataFrame(data,columns)
df.show()

# COMMAND ----------

df.groupBy("Product").pivot("Country").sum("Amount").show()

# COMMAND ----------

df1=df.groupBy("Product").pivot("Country").sum("Amount")


# COMMAND ----------

df1.show()

# COMMAND ----------

from pyspark.sql.functions import expr
df1.select("product",expr("stack(4,'Germany',Germany,'Mexico',Mexico,'Russia',Russia,'USA',USA) as (country,total)")).show()

# COMMAND ----------

