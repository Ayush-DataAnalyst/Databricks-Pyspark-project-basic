# Databricks notebook source
# MAGIC %md
# MAGIC # **INTERVIEW QUESTION**
# MAGIC ## 1 question
# MAGIC **1. We are getting data in the form of string JSON we need to convert into json format** 
# MAGIC
# MAGIC **2. After converting we need to create seperate column from the json body.** 
# MAGIC
# MAGIC **SOLVE USING PYSPARK AND SPARK SQL**

# COMMAND ----------

data=[('Manish','{"street": "123 St", "city": "Delhi"}'),('Ram','{"street": "456 St", "city": "Mumbai"}')]
schema=['name','address']
df=spark.createDataFrame(data,schema)
print(df.printSchema())
display(df)

# COMMAND ----------

df.createOrReplaceTempView("sample")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sample

# COMMAND ----------

# DBTITLE 1,We are getting data in the form of string JSON we need to convert into json format
# MAGIC %sql
# MAGIC select name,address,from_json(address,'street string,city string') as address_new from sample 

# COMMAND ----------

# DBTITLE 1,After converting we need to create seperate column from the json body.
# MAGIC %sql
# MAGIC with cte as(
# MAGIC select name,address,from_json(address,'street string,city string') as address_new from sample 
# MAGIC )
# MAGIC select name,address,address_new,address_new.street as street ,address_new.city as city from cte

# COMMAND ----------

# DBTITLE 1,SOLVE USING PYSPARK
display(df)

# COMMAND ----------

from pyspark.sql.functions import *
df1=df.withColumn('address_new',from_json(col('address'),'street string,city string'))
display(df1)

# COMMAND ----------

display(df1.select('name','address','address_new',col('address_new').street.alias('street'),col('address_new').city.alias('city')))

# COMMAND ----------

