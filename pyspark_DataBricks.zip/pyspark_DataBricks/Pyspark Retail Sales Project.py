# Databricks notebook source
dbutils.widgets.dropdown("time_period",'Weekly',['Weekly','Monthly'])

# COMMAND ----------

from datetime import date,timedelta,datetime
from pyspark.sql.functions import * 

time_period= dbutils.widgets.get("time_period")
print(time_period)
today = date.today()

if time_period=='Weekly':
    start_date=today-timedelta(days=today.weekday(),weeks=1)-timedelta(days=1)
    end_date=start_date+timedelta(days=6)

else:
    first=today.replace(day=1)
    end_date=first-timedelta(days=1)
    start_date=first-timedelta(days=end_date.day)

print(start_date,end_date)


# COMMAND ----------

df = spark.read.csv("/FileStore/tables/superstore.csv",header=True,inferSchema=True)
display(df)

# COMMAND ----------

df.createOrReplaceTempView("sample")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sample

# COMMAND ----------

# DBTITLE 1,Total number of customer
# MAGIC %sql
# MAGIC select count(distinct customer_id) as Total_Customer
# MAGIC from sample 

# COMMAND ----------

# DBTITLE 1,Total customer has done order last week/month
display(spark.sql(f""" select count(distinct customer_id) as Customer_order_lastMonth
from sample
where order_date between '{start_date}'and '{end_date}' """))

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct order_id) as Total_Customer
# MAGIC from sample 

# COMMAND ----------

display(spark.sql(f""" select count(distinct customer_id) as order_week_month
from sample
where order_date between '{start_date}'and '{end_date}' """))

# COMMAND ----------

# MAGIC %sql
# MAGIC select sum(sales) Total_sales, sum(Profit) as Total_Profit
# MAGIC from sample 

# COMMAND ----------

# DBTITLE 1,Top Sales By country
# MAGIC %sql
# MAGIC select sum(sales) Total_sales , country 
# MAGIC from sample 
# MAGIC group by country

# COMMAND ----------

# DBTITLE 1,Most profitable region/country
# MAGIC %sql
# MAGIC select sum(sales) Total_sales , country , region
# MAGIC from sample 
# MAGIC group by country,region
# MAGIC order by Total_sales

# COMMAND ----------

# DBTITLE 1,Top sales catagory Product
# MAGIC %sql
# MAGIC select sum(sales) Total_sales , category
# MAGIC from sample 
# MAGIC group by category
# MAGIC order by Total_sales desc 

# COMMAND ----------

# DBTITLE 1,Top 10 sales sub-category
# MAGIC %sql
# MAGIC select sum(sales) Total_sales , sub_category
# MAGIC from sample
# MAGIC group by sub_category
# MAGIC order by Total_sales desc limit 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from sample

# COMMAND ----------

# DBTITLE 1,Most Ordered Quantity product
# MAGIC %sql
# MAGIC select Product_name , sum(Quantity) as ordered_quantity
# MAGIC from sample
# MAGIC group by Product_name
# MAGIC order by ordered_quantity desc ;

# COMMAND ----------

# DBTITLE 1,Top 10 Customer based on sales city
# MAGIC %sql
# MAGIC select customer_name , sum(sales) Total_sales ,city
# MAGIC from sample
# MAGIC group by customer_name,city
# MAGIC order by Total_sales desc limit 10 ;

# COMMAND ----------

