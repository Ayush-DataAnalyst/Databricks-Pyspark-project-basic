# Databricks notebook source
data = [("2022-03-15", "2022-03-16 12:34:56.789"), 
        ("2022-03-01", "2022-03-16 01:23:45.678")]
df = spark.createDataFrame(data, ["date_col", "timestamp_col"])
df.show()

# COMMAND ----------

from pyspark.sql.functions import *

df.select("date_col",date_format("date_col","yyyy/MM/dd").alias("date")).show()

# COMMAND ----------

df.select("date_col",date_format("date_col","yyyy/MMMM/dd").alias("date")).show()

# COMMAND ----------

