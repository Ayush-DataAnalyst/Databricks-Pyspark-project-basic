# Databricks notebook source
# MAGIC %md
# MAGIC /FileStore/tables/department.csv
# MAGIC /FileStore/tables/employee.csv
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC /FileStore/tables/department_1-1.csv

# COMMAND ----------

# MAGIC %md
# MAGIC /FileStore/tables/department_1.csv

# COMMAND ----------

emp_df=spark.read.csv("/FileStore/tables/employee.csv",header=True,inferSchema=True)
emp_df.show()

# COMMAND ----------

dept_df=spark.read.csv("/FileStore/tables/department_1-1.csv",header=True,inferSchema=True)
dept_df.show()

# COMMAND ----------

# DBTITLE 1,Inner Join
emp_df.join(dept_df,emp_df.emp_id==dept_df.user,"inner").show()

# COMMAND ----------

emp_df.join(dept_df,emp_df.emp_id==dept_df.user,'left').show()

# COMMAND ----------

emp_df.join(dept_df,emp_df.emp_id==dept_df.user,'right').show()

# COMMAND ----------

emp_df.join(dept_df,emp_df.emp_id==dept_df.user,'fullouter').show()

# COMMAND ----------

emp_df.join(dept_df,emp_df.emp_id==dept_df.user,'leftsemi').show()

# COMMAND ----------

emp_df.join(dept_df,emp_df.emp_id==dept_df.user,'leftanti').show()

# COMMAND ----------

dept_df.join(emp_df,dept_df.user==emp_df.emp_id,'Anti').show()

# COMMAND ----------

