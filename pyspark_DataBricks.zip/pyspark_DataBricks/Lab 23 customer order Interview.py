# Databricks notebook source
customer_data=[(1,'Manish'),(2,'Ram'),(3,'Monu'),(4,'Hulara')]
schema=["Customer_ID", "Customer_Name"]

df_customer = spark.createDataFrame(customer_data,schema)
df_customer.show()

order_data=[(1,4),(3,2)]
schema1=["Order_ID", "Customer_ID"]

df_order = spark.createDataFrame(order_data,schema1)
df_order.show()


# COMMAND ----------

# DBTITLE 1,Customer who have not order anything
display(df_customer.join(df_order,df_customer.Customer_ID==df_order.Customer_ID,'left'))

# COMMAND ----------

display(df_customer.join(df_order,df_customer.Customer_ID==df_order.Customer_ID,'left').filter(df_order.Order_ID.isNull()))

# COMMAND ----------

# DBTITLE 1,Customer who have order anything
display(df_customer.join(df_order,df_customer.Customer_ID==df_order.Customer_ID,'inner'))

# COMMAND ----------

df_customer.createOrReplaceTempView("customer")
df_order.createOrReplaceTempView("order")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from customer

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from order

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from customer inner join order on customer.Customer_ID==order.Customer_ID
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC with cte as (
# MAGIC select * from customer left join order on customer.Customer_ID==order.Customer_ID
# MAGIC )
# MAGIC select * from cte where Order_ID is null
# MAGIC

# COMMAND ----------

