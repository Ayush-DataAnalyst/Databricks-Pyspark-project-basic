# Databricks notebook source
# MAGIC %md
# MAGIC  /FileStore/tables/emp_1-4.csv

# COMMAND ----------

df=spark.read.csv("/FileStore/tables/emp_1-4.csv",header=True,inferSchema=True)

# COMMAND ----------

df.show()

# COMMAND ----------

df.sort("salary").show()

# COMMAND ----------

df.orderBy("salary").show()

# COMMAND ----------

df.sort(df.salary.desc()).show()

# COMMAND ----------

df.orderBy(df.salary.desc()).show()

# COMMAND ----------

df.orderBy(df.name.desc(),df.salary.desc()).show()

# COMMAND ----------

