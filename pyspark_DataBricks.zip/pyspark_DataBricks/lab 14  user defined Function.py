# Databricks notebook source
data = [("Finance",10), \
        ("Marketing",20), \
        ("Sales",30), \
        ("IT",40) \
        ]
columns = ["dept_name","dept_id"]

df = spark.createDataFrame(data,columns)
df.show()

# COMMAND ----------

from pyspark.sql.types import LongType
def addone(a):
    return a + 1
addone_df=udf(addone,LongType())

# COMMAND ----------

df.select("dept_name","dept_id",addone_df("dept_id")).show()

# COMMAND ----------

