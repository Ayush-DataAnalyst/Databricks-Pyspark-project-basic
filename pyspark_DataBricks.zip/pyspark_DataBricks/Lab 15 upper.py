# Databricks notebook source
data = [(1,'manish',10000),(2,'Rani',50000),(3,'Sunny',5000)]
columns = ['id','name','salary']

df = spark.createDataFrame(data,columns)
df.show()

# COMMAND ----------

from pyspark.sql.functions import upper
def uppername(df):
    return df.withColumn("name",upper(df.name))

# COMMAND ----------

df.transform(uppername).show()

# COMMAND ----------

