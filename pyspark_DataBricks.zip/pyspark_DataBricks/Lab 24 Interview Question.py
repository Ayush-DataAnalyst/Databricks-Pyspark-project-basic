# Databricks notebook source
# MAGIC %md
# MAGIC # **INTERVIEW QUESTION**
# MAGIC ## **WE HAVE 2 TABLE EMPLOYEE AND DEPARTMENT TABLE IS GIVEN**
# MAGIC 1. WE HAVE TO FIND THE HIGHEST SALARY BASED ON EACH DEPARTMENT NAME
# MAGIC 2. WE HAVE TO FIND THE EMPLOYEE WHO IS GETTING HIGHEST SALARY BASED ON EACH DEPARTMENT NAME
# MAGIC 3. WE HAVE TO FIND THE lowest SALARY BASED ON EACH DEPARTMENT NAME
# MAGIC 4. WE HAVE TO FIND THE EMPLOYEE WHO IS GETTING lowest SALARY BASED ON EACH DEPARTMENT NAME
# MAGIC
# MAGIC **SOLVE USING PYSPARK AND SPARK SQL**

# COMMAND ----------

emp_data=[('Manish' , 1 , 75000),
('Raghav' , 1 , 85000 ),
('surya' , 1 , 80000 ),
('virat' , 2 , 70000),
('rohit' , 2 , 75000),
('jadeja' , 3 , 85000),
('anil' , 3 , 55000),
('sachin' , 3 , 55000),  
('zahir', 4, 60000),
('bumrah' , 4 , 65000) ]
schema= ["emp_name" ,"dept_id" ,"salary"]

emp_df=spark.createDataFrame(emp_data,schema)
emp_df.show()

dept_data = [(1, 'DATA ENGINEER'),(2, 'SALES'),(3, 'SOFTWARE'),(4, 'HR')]
schema1=['dept_id','dept_name']

dept_df=spark.createDataFrame(dept_data,schema1)
dept_df.show()


# COMMAND ----------

emp_df.join(dept_df,emp_df.dept_id==dept_df.dept_id,'left').show()

# COMMAND ----------

# DBTITLE 1,WE HAVE TO FIND THE HIGHEST SALARY BASED ON EACH DEPARTMENT NAME
from pyspark.sql.functions import *
df = emp_df.join(dept_df,emp_df.dept_id==dept_df.dept_id,'left')
df.groupBy("dept_name").agg(max("salary").alias('max_sal')).show()

# COMMAND ----------

df1 = df.groupBy("dept_name").agg(max("salary").alias('max_sal'))
df1.show()

# COMMAND ----------

# DBTITLE 1,WE HAVE TO FIND THE EMPLOYEE WHO IS GETTING HIGHEST SALARY BASED ON EACH DEPARTMENT NAME
df2 = df.join(df1,df.dept_name==df1.dept_name,'left')

# COMMAND ----------

df2.filter(col('salary')==col('max_sal')).show()

# COMMAND ----------

# DBTITLE 1,WE HAVE TO FIND THE lowest SALARY BASED ON EACH DEPARTMENT NAME
from pyspark.sql.functions import *
df5 = emp_df.join(dept_df,emp_df.dept_id==dept_df.dept_id,'left')
df.groupBy("dept_name").agg(min("salary").alias('min_sal')).show()

# COMMAND ----------

df6 = df.groupBy("dept_name").agg(min("salary").alias('min_sal'))
df6.show()

# COMMAND ----------

# DBTITLE 1,WE HAVE TO FIND THE EMPLOYEE WHO IS GETTING lowest SALARY BASED ON EACH DEPARTMENT NAME
df7 = df.join(df6,df.dept_name==df1.dept_name,'left')

# COMMAND ----------

df7.filter(col('salary')==col('min_sal')).show()

# COMMAND ----------

