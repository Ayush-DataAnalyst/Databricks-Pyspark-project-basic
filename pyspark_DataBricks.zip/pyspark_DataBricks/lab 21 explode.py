# Databricks notebook source
data = [
  ("Manish",["Java","Scala","C++"]),
  ("rahul",["Spark","Java","C++","Spark","Java"]),
  ("shyam",["CSharp","VB","Spark","Python"])
]
columns=["name","language"]

df = spark.createDataFrame(data,columns)
df.show()

# COMMAND ----------

from pyspark.sql.functions import *

df.select("name",explode(col("language"))).show()

# COMMAND ----------

df.createOrReplaceTempView("sample")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sample

# COMMAND ----------

# MAGIC %sql 
# MAGIC select name, explode(language) from sample

# COMMAND ----------

