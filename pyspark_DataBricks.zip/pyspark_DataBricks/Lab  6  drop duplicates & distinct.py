# Databricks notebook source
df = spark.read.csv("/FileStore/tables/emp_1-2.csv",header=True,inferSchema=True)

# COMMAND ----------

df.show()

# COMMAND ----------

df1 = df.distinct()

# COMMAND ----------

df1.show()

# COMMAND ----------

df2 = df.dropDuplicates(['emp_id','salary'])
df2.show()

# COMMAND ----------

