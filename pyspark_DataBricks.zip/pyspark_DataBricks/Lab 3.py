# Databricks notebook source
# MAGIC %md
# MAGIC  /FileStore/tables/emp_1-1.csv

# COMMAND ----------

df = spark.read.csv("/FileStore/tables/emp_1-1.csv", header=True,inferSchema=True)

# COMMAND ----------

df.show()

# COMMAND ----------

df.select("emp_id","salary").show()

# COMMAND ----------

df.select(df.emp_id,df.salary).show()

# COMMAND ----------

df.select(df.columns[1:4]).show()

# COMMAND ----------

# DBTITLE 1,addnew column based on existing column
df.withColumn("salary",df.salary*10).show()

# COMMAND ----------

from pyspark.sql.functions import lit

df.withColumn("country",lit("usa")).show()

# COMMAND ----------

df.withColumn("increment",lit("0")).show()

# COMMAND ----------

# DBTITLE 1,Update existing schema
df.printSchema()

# COMMAND ----------

from pyspark.sql.functions import col
df1 = df.withColumn("salary",col("salary").cast("integer"))

# COMMAND ----------

df1.show()

# COMMAND ----------

df1.printSchema()

# COMMAND ----------

df.withColumnRenamed("loc","location").show()

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

