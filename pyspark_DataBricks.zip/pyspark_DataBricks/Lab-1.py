# Databricks notebook source
df = spark.read.csv('/FileStore/tables/emp_1.csv')

# COMMAND ----------

df.show()

# COMMAND ----------

display(df)

# COMMAND ----------

df1 =spark.read.csv('/FileStore/tables/emp_1.csv', header=True)

# COMMAND ----------

display(df1)

# COMMAND ----------

df1.printSchema()

# COMMAND ----------

df2 =spark.read.csv('/FileStore/tables/emp_1.csv', header=True,inferSchema=True)

# COMMAND ----------

display(df2)

# COMMAND ----------

df2.printSchema()

# COMMAND ----------

df3 = spark.read.format("csv").options(header=True,inferSchema=True).load('/FileStore/tables/emp_1.csv')

# COMMAND ----------

display(df3)

# COMMAND ----------

df3.printSchema()

# COMMAND ----------

