# Databricks notebook source
data = [(1,"abc@gmail.com"),(2,"def@gmail.com"),(1,"abc@gmail.com")]
column=['id','name']

df = spark.createDataFrame(data,column)
df.show()

# COMMAND ----------

from pyspark.sql.functions import col
display(df.groupBy("name").count().filter(col('count')>1))

# COMMAND ----------

df.createOrReplaceTempView("sample")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sample

# COMMAND ----------

# MAGIC %sql 
# MAGIC select count(*),name from sample 
# MAGIC group by name 
# MAGIC having count(*)>1

# COMMAND ----------

# DBTITLE 1,remove duplicate
# MAGIC %sql
# MAGIC select distinct id,name from sample

# COMMAND ----------

df.distinct().show()

# COMMAND ----------

