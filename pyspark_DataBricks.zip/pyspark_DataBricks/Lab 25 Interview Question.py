# Databricks notebook source
# MAGIC %md
# MAGIC # **INTERVIEW QUESTION**
# MAGIC ## 2 question
# MAGIC 1. WE HAVE TO flatten data from 1 row to multiple row eg . [1,2,3] we need to convert into row wise flattening
# MAGIC 2. WE HAVE TO FIND OUT device pinged or not
# MAGIC
# MAGIC **SOLVE USING PYSPARK AND SPARK SQL**
# MAGIC

# COMMAND ----------

# DBTITLE 1,flatten data from 1 row to multiple row eg . [1,2,3]
from pyspark.sql.functions import * 
data = [(1,['mobile','PC','Tab']),(2,['mobile','PC']),(3,['Tab','Pen'])]
schema=['customer_id','product_purchase']

df = spark.createDataFrame(data,schema)
df.withColumn('product',explode('product_purchase')).select('customer_id','product').show()
# df.show()

# COMMAND ----------

# DBTITLE 1,WE HAVE TO FIND OUT device pinged or not
data=[(1, 'yes',None,None),(2, None,'yes',None),(3, 'No',None,'yes')]
schema=['customer_id','device_using1','device_using2','device_using3']

df1 = spark.createDataFrame(data,schema)
df1.withColumn('new',coalesce(col('device_using1'),col('device_using2'),col('device_using3'))).show()
# df1.show()

# COMMAND ----------

