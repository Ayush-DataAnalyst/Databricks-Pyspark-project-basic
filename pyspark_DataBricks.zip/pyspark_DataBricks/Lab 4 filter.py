# Databricks notebook source
df = spark.read.csv("/FileStore/tables/emp_1-2.csv",header=True,inferSchema=True)

# COMMAND ----------

df.show()

# COMMAND ----------

df.filter(df.address=='india').show()

# COMMAND ----------

df.filter(df.address!='india').show()

# COMMAND ----------

df.show()

# COMMAND ----------

df.filter((df.name=='manish')&(df.salary=='10000')).show()

# COMMAND ----------

df.filter((df.name=='manish') | (df.salary=='10000')).show()

# COMMAND ----------

df.filter(df.name.startswith("r")).show()

# COMMAND ----------

df.filter(df.name.endswith("l")).show()

# COMMAND ----------

df.show()

# COMMAND ----------

df.filter(df.name.like("%ul%")).show()

# COMMAND ----------

